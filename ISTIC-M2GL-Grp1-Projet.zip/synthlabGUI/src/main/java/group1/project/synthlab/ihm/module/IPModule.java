package group1.project.synthlab.ihm.module;

public interface IPModule extends IPModuleObservable {

}
