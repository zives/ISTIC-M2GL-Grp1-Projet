package group1.project.synthlab.ihm.module.eqView;

import group1.project.synthlab.ihm.module.IPModule;


public interface IPEQViewModule extends IPModule  {
	
}
