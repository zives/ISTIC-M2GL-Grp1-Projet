package group1.project.synthlab.ihm.module.multiplexer;

import group1.project.synthlab.ihm.module.IPModule;

public interface IPMultiplexerModule extends IPModule {
	
}
