package group1.project.synthlab.ihm.module.eg;

import group1.project.synthlab.module.eqView.IEQViewModule;


public interface ICEQModule extends IEQViewModule {
	public IPEGModule getPresentation();
}
