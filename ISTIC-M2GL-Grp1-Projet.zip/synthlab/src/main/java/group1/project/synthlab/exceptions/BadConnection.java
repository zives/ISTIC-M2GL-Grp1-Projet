package group1.project.synthlab.exceptions;

public class BadConnection extends Exception {

	private static final long serialVersionUID = 1L;

	public BadConnection(String message) {
		super(message);
	}

}
