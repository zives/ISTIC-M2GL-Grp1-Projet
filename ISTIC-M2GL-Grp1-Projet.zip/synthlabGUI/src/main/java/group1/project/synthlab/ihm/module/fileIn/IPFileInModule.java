package group1.project.synthlab.ihm.module.fileIn;

import group1.project.synthlab.ihm.module.IPModule;

public interface IPFileInModule extends IPModule {

}
