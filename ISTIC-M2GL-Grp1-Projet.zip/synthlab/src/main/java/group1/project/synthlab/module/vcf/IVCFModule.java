package group1.project.synthlab.module.vcf;

import group1.project.synthlab.module.IModule;

public interface IVCFModule extends IModule {

}
