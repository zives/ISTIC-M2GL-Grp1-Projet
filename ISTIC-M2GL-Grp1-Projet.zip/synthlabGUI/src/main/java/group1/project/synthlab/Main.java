package group1.project.synthlab;

import group1.project.synthlab.ihm.workspace.CWorkspace;

public class Main {
	public static void main(String args[]) {
		CWorkspace ws = (CWorkspace) CWorkspace.getInstance();
	}
}
