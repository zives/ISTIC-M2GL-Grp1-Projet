package group1.project.synthlab.ihm.port.in;

import group1.project.synthlab.ihm.port.IPPort;

public interface IPInPort extends IPPort {
	public void refresh();
}
