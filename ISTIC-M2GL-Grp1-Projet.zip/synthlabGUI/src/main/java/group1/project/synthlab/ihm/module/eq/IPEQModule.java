package group1.project.synthlab.ihm.module.eq;

import group1.project.synthlab.ihm.module.IPModule;

public interface IPEQModule extends IPModule {
	
}
