package group1.project.synthlab.ihm.module;

public interface IPModuleObserver {
	public void moduleMove(IPModuleObservable subject); 
}
