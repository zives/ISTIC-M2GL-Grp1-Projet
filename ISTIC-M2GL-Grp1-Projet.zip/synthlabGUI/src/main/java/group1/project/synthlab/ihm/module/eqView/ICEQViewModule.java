package group1.project.synthlab.ihm.module.eqView;

import java.awt.event.MouseEvent;

import group1.project.synthlab.ihm.module.ICModule;
import group1.project.synthlab.ihm.module.vco.ICVCOModule;
import group1.project.synthlab.module.eqView.IEQViewModule;

public interface ICEQViewModule extends ICModule, IEQViewModule {
}
