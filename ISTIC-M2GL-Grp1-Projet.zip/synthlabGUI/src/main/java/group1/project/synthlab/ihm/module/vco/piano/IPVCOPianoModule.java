package group1.project.synthlab.ihm.module.vco.piano;

import java.awt.Cursor;
import java.awt.event.MouseEvent;

import group1.project.synthlab.ihm.module.vco.IPVCOModule;

public interface IPVCOPianoModule extends IPVCOModule {
	public void mouseEvent(MouseEvent me);
}
